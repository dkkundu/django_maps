"""Core > apps.py"""
# DJANGO IMPORTS
from django.apps import AppConfig


class CoreConfig(AppConfig):
    """Core app configuration"""
    name = 'Core'
