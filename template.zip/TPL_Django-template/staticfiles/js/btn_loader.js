$("form").submit(function () {
    $("#submit").prop("hidden", true);
    $("#loader").removeAttr("hidden");
});